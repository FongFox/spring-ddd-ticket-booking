package com.vetautet.ddd.controller.resource;

import java.security.SecureRandom;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.vetautet.ddd.application.service.event.IEventAppService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;

@RestController
@RequestMapping("hello")
public class HiController {
    private final IEventAppService eventAppService;
    private final RestTemplate restTemplate;

    public HiController(IEventAppService eventAppService, RestTemplate restTemplate) {
        this.eventAppService = eventAppService;
        this.restTemplate = restTemplate;
    }

    @GetMapping("hi")
    @RateLimiter(name = "backendA", fallbackMethod = "fallbackHello")
    public String getHello() {
        // return new String("Hello world!");
        return eventAppService.sayHi("who???");
    }

    public String fallbackHello(Throwable throwable) {
        return "Too many request!\n";
    }

    @GetMapping("hi/v1")
    @RateLimiter(name = "backendB", fallbackMethod = "fallbackHello")
    public String getHi() {
        // return new String("Hello world!");
        return eventAppService.sayHi("who???");
    }

    private static final SecureRandom secureRandom = new SecureRandom();
    @GetMapping("circuit/breaker")
    @CircuitBreaker(name = "checkRandom", fallbackMethod = "fallbackCircuitBreaker")
    public String circuitBreaker() {
        // call sample API (from fakestore API) "https://fakestoreapi.com/products/7"
        int productId = secureRandom.nextInt(20) + 1;
        String url = "https://fakestoreapi.com/products/" + productId;
        
        return restTemplate.getForObject(url, String.class);
    }

    public String fallbackCircuitBreaker(Throwable throwable) {
        return new String("Service fakestore API Error!");
    }

}